local M = {

score = 0
}

return M